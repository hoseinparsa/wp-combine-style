=== WP Combine Styles ===
Contributors: hoseinparsa
Donate link: http://hparsa.ir/
Tags: litespeed, cache, combine_style, combine, styles, Combine Styles, litespeedcache,farsi, persian, iran
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

this is a free plugin to combine all css styles that queue in admin pages and can be private

== Description ==

this plugin can combine styles admin page without set setting 
and you can set time to clean styles that created 
and this operation is automatic clean styles 4000 min and you can change it

== Installation ==

1. upload `WP Combine Styles` foloder to the `/wp-content/plugins/` dirctory
2. after install active plugin and set time to clean combine styles

== Changelog ==
= 1.3 =
* fix errors

= 1.2=
* fix errors

= 1.1 =
* fix errors and update plugin

= 1.0 =
* create plugin
